export { Nod } from './Nod.js';
export { Jump } from './Jump.js';
export { SwayBody } from './SwayBody.js';
export { WaveHand } from './WaveHand.js';
export { StompFoot } from './StompFoot.js';
export { Walk } from './Walk.js';
export { Swim } from './Swim.js';
export { SplashPaddle } from './SplashPaddle.js';
export { TurnToCamera } from './TurnToCamera.js';
export { SwingRacket } from './SwingRacket.js';
export { Run } from './Run.js';
export { Bow } from './Bow.js';
export { ShakeHead } from './ShakeHead.js';
export { LookAround } from './LookAround.js';
export { PointForward } from './PointForward.js';
export { ScratchHead } from './ScratchHead.js';
export { HandsOnHips } from './HandsOnHips.js';
export { ClapHands } from './ClapHands.js';
export { Celebrate } from './Celebrate.js';
export { Shrug } from './Shrug.js';
export { SurprisedJump } from './SurprisedJump.js';
export { Tremble } from './Tremble.js';
export { Think } from './Think.js';
export { SitDown } from './SitDown.js';
export { CrossArms } from './CrossArms.js';
export { FlailArms } from './FlailArms.js';
export { LookUp } from './LookUp.js';
export { ReachOut } from './ReachOut.js';
export { WaveUp } from './WaveUp.js';
export { PullOpenDrawer } from './PullOpenDrawer.js';
export { JumpIntoDrawer } from './JumpIntoDrawer.js';

import { Nod } from './Nod.js';
import { Jump } from './Jump.js';
import { SwayBody } from './SwayBody.js';
import { WaveHand } from './WaveHand.js';
import { StompFoot } from './StompFoot.js';
import { Walk } from './Walk.js';
import { TurnToCamera } from './TurnToCamera.js';
import { SwingRacket } from './SwingRacket.js';
import { Run } from './Run.js';
import { Bow } from './Bow.js';
import { ShakeHead } from './ShakeHead.js';
import { LookAround } from './LookAround.js';
import { PointForward } from './PointForward.js';
import { ScratchHead } from './ScratchHead.js';
import { HandsOnHips } from './HandsOnHips.js';
import { ClapHands } from './ClapHands.js';
import { Celebrate } from './Celebrate.js';
import { Shrug } from './Shrug.js';
import { SurprisedJump } from './SurprisedJump.js';
import { Tremble } from './Tremble.js';
import { Think } from './Think.js';
import { SitDown } from './SitDown.js';
import { CrossArms } from './CrossArms.js';
import { FlailArms } from './FlailArms.js';
import { LookUp } from './LookUp.js';
import { ReachOut } from './ReachOut.js';
import { WaveUp } from './WaveUp.js';
import { PullOpenDrawer } from './PullOpenDrawer.js';
import { JumpIntoDrawer } from './JumpIntoDrawer.js';

export const CommonAnimations = {
  Nod,
  Jump,
  SwayBody,
  WaveHand,
  StompFoot,
  Walk,
  Swim,
  SplashPaddle,
  TurnToCamera,
  SwingRacket,
  Run,
  Bow,
  ShakeHead,
  LookAround,
  PointForward,
  ScratchHead,
  HandsOnHips,
  ClapHands,
  Celebrate,
  Shrug,
  SurprisedJump,
  Tremble,
  Think,
  SitDown,
  CrossArms,
  FlailArms,
  LookUp,
  ReachOut,
  WaveUp,
  PullOpenDrawer,
  JumpIntoDrawer,
};
