export { PullOutRacket } from './PullOutRacket.js';
export { ReachHand } from './ReachHand.js';
export { Spin } from './Spin.js';
export { PanicSpin } from './PanicSpin.js';
export { NoseBlink } from './NoseBlink.js';
export { Float } from './Float.js';
export { WaddleWalk } from './WaddleWalk.js';
export { TakeOutFromPocket } from './TakeOutFromPocket.js';
export { SearchPocket } from './SearchPocket.js';

import { PullOutRacket } from './PullOutRacket.js';
import { ReachHand } from './ReachHand.js';
import { Spin } from './Spin.js';
import { PanicSpin } from './PanicSpin.js';
import { NoseBlink } from './NoseBlink.js';
import { Float } from './Float.js';
import { WaddleWalk } from './WaddleWalk.js';
import { TakeOutFromPocket } from './TakeOutFromPocket.js';
import { SearchPocket } from './SearchPocket.js';

export const DoraemonAnimations = {
  PullOutRacket,
  ReachHand,
  Spin,
  PanicSpin,
  NoseBlink,
  Float,
  WaddleWalk,
  TakeOutFromPocket,
  SearchPocket,
};
